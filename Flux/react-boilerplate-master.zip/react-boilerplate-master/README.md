# react-boilerplate

Quickstart project template for building `npm` modules with React and JSX.

Just `npm install` and `npm run build` when you're done. Use `npm start` to continuously build.
